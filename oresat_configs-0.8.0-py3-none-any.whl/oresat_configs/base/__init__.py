"""OreSat od base configs."""
